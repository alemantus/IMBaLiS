IoT_host is responsible for the remote IoT functionality, as there is a conflict in the main code.
The main code is in the current folder.